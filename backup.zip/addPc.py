import customtkinter
import tkinter
import re
from db import *
from CTkMessagebox import CTkMessagebox

customtkinter.set_appearance_mode("Dark")
customtkinter.set_default_color_theme("blue")


sql = SQL(server='DDLAPTOP\SQLEXPRESS', database='PC')
sql.connect()


class addPC(customtkinter.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.create_widgets()

    def create_widgets(self):
        self.title("Add Computer")
        self.geometry("600x555")
        self.minsize  (600, 555)
        self.maxsize  (600, 555)
        self.frame = customtkinter.CTkFrame(self)

        self.tabview = customtkinter.CTkTabview(master=self,height=535,width=580)
        self.tabview.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        self.tabview.add("Описание")  
        self.tabview.add("Детальное описание") 

        
        
        #делаем описание
        labels_text = ["ip", "network_name", "place_of_installation","description"]
        labels_text_ru = ["IP Адрес", "Сетевое имя", "Место установки","Описание"]

        

        size = len(labels_text)
        self.tabview.tab("Описание").grid_columnconfigure((1),weight=1)
        self.tabview.tab("Описание").grid_rowconfigure((0,1,2,3,),weight=1)
        self.tabview.tab("Детальное описание").grid_rowconfigure((0,1,2,3,4,5,6),weight=1)
        self.widgetsDescription=[]
        
        for i, text in enumerate(labels_text_ru):
            label = customtkinter.CTkLabel(master=self.tabview.tab("Описание"), text=text, font=("Arial", 12))
            label.grid(row=i, column=0, padx=10, pady=10, sticky="ew")
            
            if text=="IP Адрес":
                entry = customtkinter.CTkEntry(master=self.tabview.tab("Описание"), placeholder_text="IP Адрес")
                entry.grid(row=i, column=1, padx=10, pady=10, sticky="ew")
                self.widgetsDescription.append(entry)
            elif text=="Сетевое имя":
                entry = customtkinter.CTkEntry(master=self.tabview.tab("Описание"), placeholder_text="Сетевое имя")
                entry.grid(row=i, column=1, padx=10, pady=10, sticky="ew")       
                self.widgetsDescription.append(entry)         
            else:                
                textBox=customtkinter.CTkTextbox(master=self.tabview.tab("Описание"),height=100)
                textBox.grid(row=i, column=1, padx=10, pady=10, sticky="ew")
                self.widgetsDescription.append(textBox)
        
        
        self.AddPcBasicButton = customtkinter.CTkButton(master=self.tabview.tab("Описание"), text="Добавить", command=lambda: self.AddPcBasic())
        self.AddPcBasicButton.grid(row=5, column=0,columnspan=2, pady=10, padx=10, sticky="ew")
            

        
        
        
        #делаем делатьное описание
        labels_text_detail_ru=["Детальное описание","Инв. №","Серийный №","MAC-адрес","Wake on LAN","Пороль VNC"]
        labels_text_detail = ["detailed_information","inventory_number","serial_number","mac_address","wake_on_lan","vnc_password"]
        
        self.widgetsDetailDescription=[]
        
        for i,text in enumerate(labels_text_detail_ru):
            label = customtkinter.CTkLabel(master=self.tabview.tab("Детальное описание"), text=text, font=("Arial", 12))
            label.grid(row=i, column=0, padx=10, pady=10, sticky="ew")
            
    def AddPcBasic(self):
        
        values = []
        for widget in self.widgetsDescription:
            if isinstance(widget, customtkinter.CTkEntry):
                value = widget.get()  # Получение значения из CTkEntry
            elif isinstance(widget, customtkinter.CTkTextbox):
                value = widget.get("1.0", "end-1c")  # Получение значения из CTkTextbox
            else:
                value = None
            values.append(value)   
        try:
            for text in values:
                if(text!=''):
                    pass
                else:
                    raise IOError("Не заполнены поля")

            if self.check_ip_address(values[0])==True:
                pass
            else:
                raise ValueError("Неправильный формат IP-адреса") 
            sql.add_basic_info(*values)
            
        except ValueError as e:
            CTkMessagebox(title="Ошибка",message="Неправильный формат IP-адреса.", icon="cancel")
        except IOError as e:
            CTkMessagebox(title="Ошибка",message="Не заполнены все поля", icon="cancel")

        
        
    @staticmethod  
    def check_ip_address(ip_str):
        pattern = r'^(25[0-6]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-6]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-6]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-6]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        if re.match(pattern, ip_str):
            return True
        else:
            return False


            
            

            





#CTkMessagebox(title="Ошибка",
#                              message="Заполните все поля.", icon="cancel")
#CTkMessagebox(title="УРА", message="Компьютер успешно добавлен!",
#                          icon="check", option_1="Ok")
#CTkMessagebox(title="ОШИБКА", message=f"Не удалось добавит компьютер: {
#                          e}", icon="cancel")



if __name__ == "__main__":
    root = tkinter.Tk()
    app = addPC(root)
    root.mainloop()
    