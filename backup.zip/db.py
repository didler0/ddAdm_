import pyodbc
from datetime import datetime
class SQL:
    def __init__(self, server, database):
        self.server = server
        self.database = database
        self.connection = None
        self.cursor = None

    def connect(self):
        try:
            self.connection = pyodbc.connect(
                f'DRIVER={{SQL Server}};SERVER={self.server};DATABASE={self.database};Trusted_Connection=yes;')
            self.cursor = self.connection.cursor()
            print("Connection established successfully.")
        except Exception as e:
            print(f"Error establishing connection: {str(e)}")

    def create_tables_if_not_exist(self):
        try:
            #Проверка на наличие basic_info и ее создание
            self.cursor.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'basic_info'")
            if self.cursor.fetchone()[0] == 0:
                self.cursor.execute('''
                    CREATE TABLE basic_info (
                        id INT IDENTITY(1,1) PRIMARY KEY,
                        ip VARCHAR(15),
                        network_name VARCHAR(50),
                        place_of_installation VARCHAR(50),
                        description VARCHAR(100),
                        last_status BIT,
                        data_status DATETIME,
                        last_repair DATE DEFAULT '-----'
                                            )
                ''')
                 # Создание триггера trg_StatusUpdate (если нету таблички)
                self.cursor.execute('''
                    USE PC;
                    CREATE TRIGGER trg_StatusUpdate
                    ON basic_info
                    AFTER INSERT, UPDATE
                    AS
                    BEGIN
                        DECLARE @ip VARCHAR(15)
                        DECLARE @last_status BIT
                        DECLARE @data_status DATETIME

                        SELECT @ip = inserted.ip, @last_status = inserted.last_status, @data_status = inserted.data_status
                        FROM inserted

                        INSERT INTO statuses (basic_info_id, status_, status_date)
                        SELECT id, @last_status, @data_status
                        FROM basic_info
                        WHERE ip = @ip
                    END
                ''')
                self.cursor.execute('''
                INSERT INTO basic_info (ip, network_name, place_of_installation, description, last_status, data_status, last_repair)
                VALUES ('192.168.1.1', 'Network1', 'Location1', 'Description1', 0, GETDATE(), GETDATE())
            ''')
                self.connection.commit()
                print("Table basic_info created.")

            # Проверка на наличие  detail_info и ее создание
            self.cursor.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'detail_info'")
            if self.cursor.fetchone()[0] == 0:
                self.cursor.execute('''
                    CREATE TABLE detail_info (
                        id INT IDENTITY(1,1) PRIMARY KEY,
                        basic_info_id INT,
                        detailed_information VARCHAR(100),
                        inventory_number VARCHAR(20),
                        serial_number VARCHAR(20),
                        mac_address VARCHAR(17),
                        wake_on_lan VARCHAR(10),
                        vnc_password VARCHAR(20),
                        FOREIGN KEY (basic_info_id) REFERENCES basic_info(id)
                    )
                ''')
                self.connection.commit()
                print("Table detail_info created.")

            # Проверка на наличие statuses и ее создание
            self.cursor.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'statuses'")
            if self.cursor.fetchone()[0] == 0:
                self.cursor.execute('''
                    CREATE TABLE statuses (
                        id INT IDENTITY(1,1) PRIMARY KEY,
                        basic_info_id INT,
                        status_ BIT,
                        status_date DATETIME,
                        FOREIGN KEY (basic_info_id) REFERENCES basic_info(id)
                    )
                ''')
                self.connection.commit()               
                print("Table statuses created.")

            # Проверка наличия repairs и ее создание
            self.cursor.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'repairs'")
            if self.cursor.fetchone()[0] == 0:
                self.cursor.execute('''
                    CREATE TABLE repairs (
                        id INT IDENTITY(1,1) PRIMARY KEY,
                        basic_info_id INT,
                        description VARCHAR(100),
                        repair_date DATE,
                        document_path VARCHAR(100),
                        FOREIGN KEY (basic_info_id) REFERENCES basic_info(id)
                    )
                ''')
                self.connection.commit()
                print("Table repairs created.")
            
            print("All tables checked and created if necessary.")
        except Exception as e:
            print(f"Error creating tables: {str(e)}")

    def get_basic_info(self):
       try:
           #Дёргаем всю таблицу basic_info
           self.cursor.execute("SELECT * FROM basic_info")
           rows = self.cursor.fetchall()
           if rows:
               return rows
           else:
               return "No data found in basic_info table."
       except Exception as e:
           print(f"Error fetching data from basic_info table: {str(e)}")   
    
    def get_detail_info(self):
       try:
           #Дёргаем всю таблицу detail_info
           self.cursor.execute("SELECT * FROM detail_info")
           rows = self.cursor.fetchall()
           if rows:
               return rows
           else:
               return "No data found in detail_info table."
       except Exception as e:
           print(f"Error fetching data from detail_info table: {str(e)}")   

    def get_repairs(self):
       try:
           #Дёргаем всю таблицу repairs
           self.cursor.execute("SELECT * FROM repairs")
           rows = self.cursor.fetchall()
           if rows:
               return rows
           else:
               return "No data found in repairs table."
       except Exception as e:
           print(f"Error fetching data from repairs table: {str(e)}")            

    def get_statuses(self):
       try:
           #Дёргаем всю таблицу statuses
           self.cursor.execute("SELECT * FROM statuses")
           rows = self.cursor.fetchall()
           if rows:
               return rows
           else:
               return "No data found in statuses table."
       except Exception as e:
           print(f"Error fetching data from statuses table: {str(e)}")
           
    def add_status(self, ip_address, last_status):
        try:
            # Выполняем SQL-запрос для добавления нового статуса
            query = f'''
            UPDATE basic_info
            SET last_status = {int(last_status)}, data_status = GETDATE()
            WHERE ip = '{ip_address}'
            '''
            self.cursor.execute(query)
            self.connection.commit()
            print(f"Status for IP {ip_address} updated successfully.")
            self.connection.commit()
        except Exception as e:
            print(f"Error adding status: {str(e)}")
            
    def add_basic_info(self, ip, network_name, place_of_installation, description):
        try:
            # Выполняем SQL-запрос для добавления новой записи
            query = f'''
            INSERT INTO basic_info (ip, network_name, place_of_installation, description, last_status, data_status)
            VALUES ('{ip}', '{network_name}', '{place_of_installation}', '{description}', 0, GETDATE())
            '''
            self.cursor.execute(query)
            self.connection.commit()
            print("New record added successfully.")
            self.connection.commit()
        except Exception as e:
            print(f"Error adding new record: {str(e)}")

  



if __name__ == "__main__":
    sql = SQL(server='DDLAPTOP\SQLEXPRESS', database='PC')
    sql.connect()
    sql.create_tables_if_not_exist()
    
    basic_info_data = sql.get_basic_info()
    print("Data from basic_info table:")
    for row in basic_info_data:
        print(row)
